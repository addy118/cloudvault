import React from "react";
import { Button } from "./ui/button";
import { FolderPlus } from "lucide-react";

export default function LandingPage() {
  return (
      <h2 className="m-8 text-4xl font-bold text-[#EEEEEE]">
        Register on our app today itself!
      </h2>
  );
}
