import React from "react";

export default function LandingPage() {
  return (
    <h2 className="m-8 text-4xl font-bold">
      Register on our app today itself!
    </h2>
  );
}
